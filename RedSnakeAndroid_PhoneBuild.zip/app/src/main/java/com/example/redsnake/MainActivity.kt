package com.example.redsnake

import android.app.Activity
import android.os.Bundle
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.graphics.Typeface
import kotlin.math.abs
import kotlin.random.Random

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        setContentView(SnakeGameView(this))
    }
}

private class SnakeGameView(context: Context) : View(context) {
    private data class Cell(val x: Int, val y: Int)

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val cols = 20
    private var rows = 30
    private val snake = mutableListOf(Cell(9, 15), Cell(8, 15), Cell(7, 15))
    private var direction = Cell(1, 0)
    private var nextDirection = direction
    private var food = Cell(14, 15)
    private var score = 0
    private var best = 0
    private var started = false
    private var paused = false
    private var gameOver = false
    private var lastStep = 0L
    private var cellSize = 0f
    private var boardLeft = 0f
    private var boardTop = 0f
    private var downX = 0f
    private var downY = 0f

    private val bg = android.graphics.Color.rgb(13, 15, 20)
    private val red = android.graphics.Color.rgb(255, 48, 68)
    private val gray = android.graphics.Color.rgb(105, 112, 125)
    private val pale = android.graphics.Color.rgb(235, 238, 244)

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(bg)
        val w = width.toFloat()
        val h = height.toFloat()
        paint.color = pale
        paint.typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
        paint.textAlign = Paint.Align.CENTER
        paint.textSize = w * 0.09f
        canvas.drawText("RED SNAKE", w / 2f, h * 0.09f, paint)

        paint.typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        paint.textSize = w * 0.042f
        paint.color = gray
        canvas.drawText("SCORE  $score       BEST  $best", w / 2f, h * 0.15f, paint)

        cellSize = (w * 0.90f) / cols
        rows = ((h * 0.68f) / cellSize).toInt().coerceAtLeast(18)
        boardLeft = (w - cols * cellSize) / 2f
        boardTop = h * 0.20f

        val board = RectF(boardLeft - 5, boardTop - 5, boardLeft + cols * cellSize + 5, boardTop + rows * cellSize + 5)
        paint.color = android.graphics.Color.rgb(27, 30, 39)
        canvas.drawRoundRect(board, 22f, 22f, paint)

        // Subtle grid
        paint.color = android.graphics.Color.rgb(39, 43, 54)
        paint.strokeWidth = 1f
        for (x in 0..cols) {
            val px = boardLeft + x * cellSize
            canvas.drawLine(px, boardTop, px, boardTop + rows * cellSize, paint)
        }
        for (y in 0..rows) {
            val py = boardTop + y * cellSize
            canvas.drawLine(boardLeft, py, boardLeft + cols * cellSize, py, paint)
        }

        // Red liquid drop
        val fx = boardLeft + (food.x + 0.5f) * cellSize
        val fy = boardTop + (food.y + 0.5f) * cellSize
        paint.setShadowLayer(18f, 0f, 0f, red)
        paint.color = red
        canvas.drawCircle(fx, fy, cellSize * 0.31f, paint)
        paint.clearShadowLayer()
        paint.color = android.graphics.Color.WHITE
        canvas.drawCircle(fx - cellSize * 0.09f, fy - cellSize * 0.10f, cellSize * 0.07f, paint)

        // Snake: alternating red and graphite segments
        snake.forEachIndexed { i, c ->
            val inset = cellSize * 0.09f
            val r = RectF(
                boardLeft + c.x * cellSize + inset,
                boardTop + c.y * cellSize + inset,
                boardLeft + (c.x + 1) * cellSize - inset,
                boardTop + (c.y + 1) * cellSize - inset
            )
            paint.setShadowLayer(if (i == 0) 14f else 4f, 0f, 0f, if (i % 2 == 0) red else gray)
            paint.color = if (i % 2 == 0) red else gray
            canvas.drawRoundRect(r, cellSize * 0.28f, cellSize * 0.28f, paint)
            paint.clearShadowLayer()
            if (i == 0) {
                paint.color = pale
                val eyeR = cellSize * 0.055f
                canvas.drawCircle(r.centerX() - cellSize * 0.12f, r.centerY() - cellSize * 0.10f, eyeR, paint)
                canvas.drawCircle(r.centerX() + cellSize * 0.12f, r.centerY() - cellSize * 0.10f, eyeR, paint)
            }
        }

        if (!started || paused || gameOver) {
            paint.color = android.graphics.Color.argb(210, 7, 9, 14)
            canvas.drawRoundRect(board, 22f, 22f, paint)
            paint.color = pale
            paint.textSize = w * 0.065f
            paint.typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            val title = when {
                gameOver -> "GAME OVER"
                paused -> "PAUSED"
                else -> "READY?"
            }
            canvas.drawText(title, w / 2f, board.centerY() - 10f, paint)
            paint.textSize = w * 0.038f
            paint.typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            val subtitle = when {
                gameOver -> "Tap to play again"
                paused -> "Tap to continue"
                else -> "Swipe to move • Tap to start"
            }
            canvas.drawText(subtitle, w / 2f, board.centerY() + cellSize, paint)
        }

        paint.color = gray
        paint.textSize = w * 0.034f
        canvas.drawText("SWIPE UP / DOWN / LEFT / RIGHT", w / 2f, h * 0.94f, paint)

        if (started && !paused && !gameOver) {
            val now = System.currentTimeMillis()
            val interval = (170L - score.coerceAtMost(90)).coerceAtLeast(75L)
            if (now - lastStep >= interval) {
                step()
                lastStep = now
            }
            postInvalidateDelayed(16)
        }
    }

    private fun step() {
        direction = nextDirection
        val head = snake.first()
        val next = Cell(head.x + direction.x, head.y + direction.y)
        if (next.x !in 0 until cols || next.y !in 0 until rows || snake.contains(next)) {
            gameOver = true
            started = false
            invalidate()
            return
        }
        snake.add(0, next)
        if (next == food) {
            score += 10
            best = maxOf(best, score)
            placeFood()
        } else {
            snake.removeAt(snake.lastIndex)
        }
        invalidate()
    }

    private fun placeFood() {
        var candidate: Cell
        do {
            candidate = Cell(Random.nextInt(cols), Random.nextInt(rows))
        } while (snake.contains(candidate))
        food = candidate
    }

    private fun reset() {
        snake.clear()
        snake.addAll(listOf(Cell(9, 15), Cell(8, 15), Cell(7, 15)))
        direction = Cell(1, 0)
        nextDirection = direction
        score = 0
        gameOver = false
        paused = false
        started = true
        placeFood()
        lastStep = System.currentTimeMillis()
        invalidate()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.x
                downY = event.y
                return true
            }
            MotionEvent.ACTION_UP -> {
                val dx = event.x - downX
                val dy = event.y - downY
                if (abs(dx) < 25f && abs(dy) < 25f) {
                    when {
                        gameOver || !started -> reset()
                        paused -> { paused = false; lastStep = System.currentTimeMillis(); invalidate() }
                        else -> { paused = true; invalidate() }
                    }
                    return true
                }
                if (abs(dx) > abs(dy)) {
                    if (dx > 0 && direction.x != -1) nextDirection = Cell(1, 0)
                    else if (dx < 0 && direction.x != 1) nextDirection = Cell(-1, 0)
                } else {
                    if (dy > 0 && direction.y != -1) nextDirection = Cell(0, 1)
                    else if (dy < 0 && direction.y != 1) nextDirection = Cell(0, -1)
                }
                if (!started || gameOver) reset()
                if (paused) paused = false
                invalidate()
                return true
            }
        }
        return true
    }
}
